from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import shlex
import signal
import subprocess
import sys
import uuid

worktree = Path('/Users/rs/code/github.com/technologylab.ai/bounded-http-windows-shards')
cache = Path('/Users/rs/code/github.com/technologylab.ai/bounded-http-windows-shards/.zig-cache/windows-shards-linux-514c901')
commit = '514c901fafd005f140a0a6fdf10ee28d0ff8796a'
remote_root = 'maintained-wrapper temporary /tmp/bounded-http.*'
token = uuid.uuid4().hex
receipt = dict(schema_version=1, commit=commit, started_utc=datetime.now(timezone.utc).isoformat(),
               root=remote_root, token=token, ok=False, timed_loads=False, commands=[])

holder_code = r'''
import json, os, re, socket, sys
from datetime import datetime,timezone
from pathlib import Path
lock=Path('/tmp/zig-http-measurement.lock')
token=sys.argv[1]
def scan():
    rows=[]
    for p in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            if int(p.parent.name)==os.getpid(): continue
            cmd=p.read_bytes().replace(b'\0',b' ').decode('utf-8','replace').strip()
            if any(x in cmd for x in ('/bin/libreactor','remote_sweep.sh','/bin/wrk','tools/compare.py','/bin/zig-http','/bin/bounded-http','/bin/embedded-http','zig build','benchmarks/prepare/prepare.py','mrhttp-build/launch.sh','tests/arena_lifecycle_integration.py','tests/integration.py','tests/batch_integration.py','tests/gather_integration.py','tests/inline_integration.py','tools/smoke.py')):
                rows.append(dict(pid=int(p.parent.name),command=cmd))
        except (FileNotFoundError,PermissionError,ProcessLookupError): pass
    return rows
existing=scan()
if existing:
    print(json.dumps(dict(status='pending',processes=existing)),flush=True);sys.exit(75)
try: lock.mkdir()
except FileExistsError:
    print(json.dumps(dict(status='pending',owner=(lock/'owner.json').read_text() if (lock/'owner.json').exists() else 'incomplete metadata')),flush=True);sys.exit(75)
owner=dict(schema=1,token=token,host=socket.gethostname(),owner='Codex /root/arena_parser_review',purpose='Exact Zig0.16.0 clean pushed Windows shards candidate514c901 Linux regression gate; no timed comparison',created_utc=datetime.now(timezone.utc).isoformat(),owner_pid=os.getpid(),owner_start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],work_root='/Users/rs/code/github.com/technologylab.ai/bounded-http-windows-shards streamed to validated remote /tmp/bounded-http.*')
(lock/'owner.json').write_text(json.dumps(owner,indent=2)+'\n')
after=scan()
if after:
    (lock/'owner.json').unlink();lock.rmdir()
    print(json.dumps(dict(status='pending',processes=after,reason='post-acquisition scan')),flush=True);sys.exit(75)
print(json.dumps(dict(status='acquired',owner=owner,processes_before=existing,processes_after=after)),flush=True)
request=sys.stdin.readline().strip()
remaining=scan()
if request!='release' or remaining:
    print(json.dumps(dict(status='retained',request=request,processes=remaining)),flush=True);sys.exit(76)
actual=json.loads((lock/'owner.json').read_text())
assert actual['token']==token and actual['owner_pid']==os.getpid()
(lock/'owner.json').unlink();lock.rmdir()
print(json.dumps(dict(status='released',owned_processes_remaining=[],released_utc=datetime.now(timezone.utc).isoformat())),flush=True)
'''

def run(argv, logname, timeout=300, cwd=worktree, stdin=None):
    record=dict(argv=argv, timeout_seconds=timeout, log=logname, started_utc=datetime.now(timezone.utc).isoformat())
    print('START '+logname+' '+record['started_utc'],flush=True)
    receipt['commands'].append(record)
    with (cache/logname).open('w') as out, (cache/(logname+'.stderr')).open('w') as error_out:
        p=subprocess.Popen(argv,cwd=cwd,stdin=stdin,stdout=out,stderr=error_out,start_new_session=True)
        try:
            p.wait(timeout=timeout)
        except BaseException:
            try: os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: p.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
            raise
    record['returncode']=p.returncode
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    print('FINISH '+logname+' '+record['finished_utc']+' exit='+str(p.returncode),flush=True)
    if p.returncode: raise subprocess.CalledProcessError(p.returncode,argv)


assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==commit
receipt['input_status']=subprocess.check_output(['git','status','--porcelain'],cwd=worktree,text=True)
receipt['publication_gate']=False
receipt['scope']='clean pushed Windows publication gate; unmodified maintained wrapper; stdout/stderr captured separately'
receipt['suite_json_capture']='Whole stdout JSON receipts preserved individually; no mixed stderr/PASS text'
receipt['tracked_hashes_before']={name:hashlib.sha256((worktree/name).read_bytes()).hexdigest() for name in subprocess.check_output(['git','ls-files'],cwd=worktree,text=True).splitlines()}
assert not receipt['input_status'].strip()
receipt['origin_feature_before']=subprocess.check_output(['git','ls-remote','origin','refs/heads/feat/windows-shards'],cwd=worktree,text=True,timeout=30).split()[0]
assert receipt['origin_feature_before']==commit
receipt['source_hashes']={str(path.relative_to(worktree)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((worktree/'src').glob('*.zig'))}
receipt['source_hashes']['tools/verify_linux_ssh.sh']=hashlib.sha256((worktree/'tools/verify_linux_ssh.sh').read_bytes()).hexdigest()
holder=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1',shlex.join(['python3','-u','-c',holder_code,token])],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert select.select([holder.stdout],[],[],20)[0], 'reservation acquisition watchdog'
line=holder.stdout.readline()
if not line: raise RuntimeError(holder.stderr.read())
initial=json.loads(line)
receipt['reservation']=initial
print(json.dumps(initial),flush=True)
(cache/'lock.json').write_text(json.dumps(initial,indent=2)+'\n')
if initial['status']!='acquired':
    holder.stdin.close();holder.wait(timeout=10)
    (cache/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    raise SystemExit(75)
try:
    run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1','uname -a; lscpu; zig version; zig env; sha256sum "$(command -v zig)"; python3 --version; powerprofilesctl get; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference'], 'environment.log',60)
    run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1',shlex.join(['python3','-c','import subprocess,re,json,hashlib;from pathlib import Path;env=subprocess.check_output([\'zig\',\'env\'],text=True,timeout=10);name=re.search(r\'\\.zig_exe = \\"([^\\"]+)\\"\',env).group(1);print(json.dumps(dict(zig_exe=name,zig_sha256=hashlib.sha256(Path(name).read_bytes()).hexdigest(),zig_version=subprocess.check_output([name,\'version\'],text=True,timeout=10).strip())))'])], 'compiler-identity.json',60)
    run(['sh','tools/verify_linux_ssh.sh','omarx1'],'gates.log',1200)
    receipt['output_status']=subprocess.check_output(['git','status','--porcelain'],cwd=worktree,text=True)
    receipt['output_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()
    receipt['origin_feature_after']=subprocess.check_output(['git','ls-remote','origin','refs/heads/feat/windows-shards'],cwd=worktree,text=True,timeout=30).split()[0]
    assert not receipt['output_status'].strip() and receipt['output_commit']==receipt['origin_feature_after']==commit
    receipt['tracked_hashes_after']={name:hashlib.sha256((worktree/name).read_bytes()).hexdigest() for name in subprocess.check_output(['git','ls-files'],cwd=worktree,text=True).splitlines()}
    assert receipt['tracked_hashes_before']==receipt['tracked_hashes_after']
    packets=[]
    for line in (cache/'gates.log').read_text().splitlines():
        if line.startswith('{'):
            try: packet=json.loads(line)
            except ValueError: continue
            if packet.get('tool'):
                packets.append(packet)
                (cache/(packet['tool']+'.json')).write_text(json.dumps(packet,indent=2)+'\n')
    assert len(packets)==6 and all(p['ok'] for p in packets), 'All five wire suites and smoke must pass'
    smoke=next(p for p in packets if p['tool']=='bounded-http-smoke-suite')
    temporary=Path(smoke['build']['binary']).parents[2]
    assert str(temporary).startswith('/tmp/bounded-http.') and temporary.parent==Path('/tmp')
    run(['ssh','omarx1',shlex.join(['test','!','-e',str(temporary)])],'temporary-cleanup.log',30)
    receipt['validated_temporary_tree_removed']=str(temporary)
    print('Clean pushed Windows shards candidate514c901 Linux native regression gates passed.',flush=True)
    receipt['ok']=True
except BaseException as error:
    receipt['error']=type(error).__name__+': '+str(error)
    raise
finally:
    holder.stdin.write('release\n');holder.stdin.flush()
    assert select.select([holder.stdout],[],[],30)[0], 'reservation release watchdog'
    result=json.loads(holder.stdout.readline());receipt['release']=result
    print(json.dumps(result),flush=True)
    holder.stdin.close();holder.wait(timeout=10)
    receipt['finished_utc']=datetime.now(timezone.utc).isoformat()
    (cache/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert result['status']=='released', 'reservation retained; inspect owned workload state'
